<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>
        <?php echo isset($page_title) ? htmlspecialchars($page_title) : "Clocky | Munkaidő"; ?>
    </title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">

    <style>
        /* Reset & Alapok */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: #090909;
            color: #fff;
            min-height: 100vh;
            padding-top: 75px;
            overflow-x: hidden;
        }

        /* --- SZEKCIÓ VÁLTÁS ANIMÁCIÓ --- */
        .page-transition {
            animation: smoothAppear 0.6s cubic-bezier(0.4, 0, 0.2, 1) forwards;
            opacity: 0;
        }

        @keyframes smoothAppear {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* --- FEJLÉC --- */
        .header-top {
            position: fixed;
            top: 15px;
            left: 15px;
            right: 15px;
            z-index: 1100;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            gap: 15px;
        }

        .menu-toggle {
            background: #1a1a1a;
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.1);
            padding: 10px 18px;
            border-radius: 12px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.4);
            transition: all 0.3s ease;
        }

        .menu-toggle span {
            display: inline-block !important;
        }

        .menu-toggle:hover {
            background: #00ffe1;
            color: #000;
            transform: translateY(-2px);
        }

        .brand-logo {
            font-weight: 800;
            font-size: 24px;
            letter-spacing: -1px;
            color: #fff;
            text-transform: lowercase;
            /* A logó marad kisbetűs stílusú */
        }

        .brand-logo span {
            color: #00ffe1;
        }

        /* --- OLDALMENÜ --- */
        nav {
            position: fixed;
            top: 10px;
            bottom: 10px;
            left: -320px;
            width: 280px;
            background: linear-gradient(145deg, #161616 0%, #0a0a0a 100%);
            z-index: 1200;
            overflow-y: auto;
            transition: left 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 20px 0 40px rgba(0, 0, 0, 0.7);
            padding-top: 80px;
            border-radius: 0 24px 24px 0;
            border-right: 1px solid rgba(0, 255, 225, 0.1);
        }

        nav.open {
            left: 0;
        }

        nav ul {
            list-style: none;
            padding: 0 15px;
        }

        nav ul li a {
            text-decoration: none;
            color: #aaa;
            font-weight: 600;
            font-size: 14px;
            padding: 16px 20px;
            border-radius: 16px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 5px;
            text-transform: none;
            /* KIKAPCSOLVA a kényszerített kisbetűzés */
        }

        nav ul li a i {
            font-size: 18px;
            width: 25px;
            text-align: center;
        }

        nav ul li a:hover,
        nav ul li a.active {
            background: rgba(0, 255, 225, 0.1);
            color: #00ffe1;
            transform: translateX(8px);
        }

        nav ul li.logout {
            margin-top: 30px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            padding-top: 15px;
        }

        nav ul li.logout a {
            color: #ff4757;
        }

        nav ul li.logout a:hover {
            background: rgba(255, 71, 87, 0.1);
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(8px);
            z-index: 1150;
        }

        .overlay.active {
            display: block;
        }

        .hamburger-lines {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .bar {
            width: 18px;
            height: 2px;
            background-color: currentColor;
            border-radius: 2px;
        }
    </style>
</head>

<body class="page-transition">

    <div id="overlay" class="overlay" onclick="toggleMenu()"></div>

    <div class="header-top">
        <button class="menu-toggle" onclick="toggleMenu()">
            <div class="hamburger-lines">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
            <span>Menü</span>
        </button>
        <div class="brand-logo">clocky<span>.</span></div>
    </div>

    <nav id="mainNav">
        <ul>
            <li><a href="<?php echo $base_url; ?>kezdolap"
                    class="<?php echo (isset($page_title) && ($page_title == 'Dashboard' || $page_title == 'Kezdőlap')) ? 'active' : ''; ?>"><i
                        class="fas fa-home"></i> Kezdőlap</a></li>
            <li><a href="<?php echo $base_url; ?>dolgozok"
                    class="<?php echo (isset($page_title) && ($page_title == 'Employees' || $page_title == 'Dolgozók')) ? 'active' : ''; ?>"><i
                        class="fas fa-users"></i> Dolgozók</a></li>
            <li><a href="<?php echo $base_url; ?>munkakorok"
                    class="<?php echo (isset($page_title) && ($page_title == 'Roles' || $page_title == 'Munkakörök')) ? 'active' : ''; ?>"><i
                        class="fas fa-briefcase"></i> Munkakörök</a></li>
            <li><a href="<?php echo $base_url; ?>uj-dolgozo"
                    class="<?php echo (isset($page_title) && $page_title == 'uj-dolgozo') ? 'active' : ''; ?>"><i
                        class="fas fa-user-plus"></i> Dolgozó hozzáadása</a></li>
            <li><a href="<?php echo $base_url; ?>uj-munkakor"
                    class="<?php echo (isset($page_title) && $page_title == 'uj-munkakor') ? 'active' : ''; ?>"><i
                        class="fas fa-plus-square"></i> Munkakör hozzáadása</a></li>
            <li><a href="<?php echo $base_url; ?>archivum"
                    class="<?php echo (isset($page_title) && $page_title == 'archivum') ? 'active' : ''; ?>"><i
                        class="fas fa-archive"></i> Archívum</a></li>
            <li><a href="<?php echo $base_url; ?>lista"
                    class="<?php echo (isset($page_title) && $page_title == 'lista') ? 'active' : ''; ?>"><i
                        class="fas fa-list"></i> Lista</a></li>

            <li class="logout"><a href="<?php echo $base_url; ?>kijelentkezes"><i class="fas fa-sign-out-alt"></i>
                    Kijelentkezés</a></li>
        </ul>
    </nav>

    <script>
        function toggleMenu() {
            const nav = document.getElementById('mainNav');
            const overlay = document.getElementById('overlay');
            nav.classList.toggle('open');
            overlay.classList.toggle('active');

            if (nav.classList.contains('open')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = 'auto';
            }
        }

        document.querySelectorAll('nav a').forEach(link => {
            link.addEventListener('click', function (e) {
                const href = this.getAttribute('href');
                if (href && !href.startsWith('#') && !href.startsWith('javascript:')) {
                    if (window.location.pathname.indexOf(href) === -1) {
                        document.body.style.opacity = '0';
                        document.body.style.transition = 'opacity 0.3s ease';
                    }
                }
            });
        });
    </script>
</body>

</html>